package com.example.autosprint

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import androidx.core.app.NotificationCompat

/**
 * Foreground-сервис, который рисует ОДНУ плавающую кнопку поверх игры.
 *
 * Идея: кнопка не читает и не перехватывает ввод игры (это технически
 * невозможно и не нужно). Вместо этого пользователь сам зажимает эту
 * кнопку пальцем, когда двигается вперёд — а сервис в ответ на удержание
 * периодически шлёт AutoSprintAccessibilityService.doubleTapAt(x, y)
 * в заранее заданную точку экрана (обычно это зона джойстика в игре),
 * эмулируя "двойной тап = спринт".
 *
 * Это простое, прозрачное решение без скрытой автоматизации боя —
 * фича активна только пока ты физически держишь палец на кнопке.
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayButton: Button? = null
    private var isHolding = false

    // Координаты, куда слать эмулированный двойной тап (зона джойстика движения в игре).
    // На реальном устройстве их нужно откалибровать под разрешение экрана и HUD игры.
    private val sprintTargetX = 200f
    private val sprintTargetY = 1600f

    override fun onCreate() {
        super.onCreate()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                1,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(1, notification)
        }
        addOverlayButton()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val channelId = "autosprint_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "AutoSprint Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NotificationManager::class.java)).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("AutoSprint активен")
            .setContentText("Держи кнопку, чтобы бежать")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun addOverlayButton() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val btn = Button(this).apply {
            text = "SPRINT"
            setBackgroundColor(Color.parseColor("#8000FF00"))
            setTextColor(Color.WHITE)
        }

        val layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        val params = WindowManager.LayoutParams(
            220, 120,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = 40
            y = 300
        }

        // Позволяем перетаскивать кнопку пальцем, чтобы поставить туда,
        // где удобно (обычно рядом со своим джойстиком в игре).
        var initialX = 0
        var initialY = 0
        var touchStartX = 0f
        var touchStartY = 0f

        btn.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    isHolding = true
                    AutoSprintAccessibilityService.instance?.startSprintLoop(
                        sprintTargetX, sprintTargetY
                    )
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    // Долгое перетаскивание (>15px) — считаем что юзер двигает кнопку,
                    // а не просто жмёт. Короткое перемещение — игнорируем, это просто дрожь пальца.
                    val dx = (event.rawX - touchStartX).toInt()
                    val dy = (event.rawY - touchStartY).toInt()
                    if (Math.abs(dx) > 30 || Math.abs(dy) > 30) {
                        params.x = initialX - dx
                        params.y = initialY - dy
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    isHolding = false
                    AutoSprintAccessibilityService.instance?.stopSprintLoop()
                    true
                }
                else -> false
            }
        }

        overlayButton = btn
        windowManager.addView(btn, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        AutoSprintAccessibilityService.instance?.stopSprintLoop()
        overlayButton?.let { windowManager.removeView(it) }
    }
}

package com.example.autosprint

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button

/**
 * Foreground-сервис, рисующий НЕСКОЛЬКО перетаскиваемых кнопок поверх игры:
 * SPRINT, JUMP, CROUCH. Каждая кнопка:
 * - имеет свой размер (побольше — легче попадать пальцем в PvP);
 * - двигается перетаскиванием (как HUD-кнопки в новых версиях Minecraft);
 * - шлёт жест в СВОЮ точку экрана (её нужно откалибровать под расположение
 *   настоящих кнопок движения/прыжка/приседа в MCPE на конкретном телефоне);
 * - ЗАПОМИНАЕТ, куда её перетащили — позиция сохраняется в SharedPreferences
 *   и восстанавливается при следующем запуске оверлея, а не сбрасывается
 *   на стартовые координаты каждый раз.
 *
 * SPRINT работает через повторяющийся двойной тап (см. AutoSprintAccessibilityService).
 * JUMP и CROUCH работают через настоящее удержание пальца (continueStroke).
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: SharedPreferences
    private val addedViews = mutableListOf<Button>()

    private data class ButtonConfig(
        val id: String,
        val label: String,
        val bgColor: String,
        val targetX: Float,
        val targetY: Float,
        val startGravity: Int,
        val defaultX: Int,
        val defaultY: Int,
        val widthPx: Int,
        val heightPx: Int
    )

    private val buttonConfigs = listOf(
        ButtonConfig(
            id = "sprint",
            label = "SPRINT",
            bgColor = "#8000FF00",
            targetX = 200f, targetY = 1600f,
            startGravity = Gravity.BOTTOM or Gravity.END,
            defaultX = 40, defaultY = 340,
            widthPx = 260, heightPx = 160
        ),
        ButtonConfig(
            id = "jump",
            label = "JUMP",
            bgColor = "#80FFAA00",
            targetX = 950f, targetY = 1550f,
            startGravity = Gravity.BOTTOM or Gravity.END,
            defaultX = 40, defaultY = 140,
            widthPx = 260, heightPx = 160
        ),
        ButtonConfig(
            id = "crouch",
            label = "CROUCH",
            bgColor = "#8000AAFF",
            targetX = 950f, targetY = 1750f,
            startGravity = Gravity.BOTTOM or Gravity.START,
            defaultX = 40, defaultY = 140,
            widthPx = 260, heightPx = 160
        )
    )

    override fun onCreate() {
        super.onCreate()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("overlay_positions", Context.MODE_PRIVATE)
        buttonConfigs.forEach { addDraggableButton(it) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val channelId = "autosprint_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "AutoSprint Overlay", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NotificationManager::class.java)).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Оверлей активен")
            .setContentText("Sprint / Jump / Crouch готовы")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    // --- Сохранение/восстановление позиции конкретной кнопки ---

    private fun loadSavedX(id: String, default: Int): Int =
        prefs.getInt("${id}_x", default)

    private fun loadSavedY(id: String, default: Int): Int =
        prefs.getInt("${id}_y", default)

    private fun savePosition(id: String, x: Int, y: Int) {
        prefs.edit()
            .putInt("${id}_x", x)
            .putInt("${id}_y", y)
            .apply()
    }

    private fun addDraggableButton(cfg: ButtonConfig) {
        val btn = Button(this).apply {
            text = cfg.label
            setBackgroundColor(Color.parseColor(cfg.bgColor))
            setTextColor(Color.WHITE)
            textSize = 14f
        }

        // Восстанавливаем сохранённую позицию, если она уже была — иначе дефолтная.
        val restoredX = loadSavedX(cfg.id, cfg.defaultX)
        val restoredY = loadSavedY(cfg.id, cfg.defaultY)

        val params = WindowManager.LayoutParams(
            cfg.widthPx, cfg.heightPx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = cfg.startGravity
            x = restoredX
            y = restoredY
        }

        var initialX = 0
        var initialY = 0
        var touchStartX = 0f
        var touchStartY = 0f
        var isDragging = false

        btn.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    isDragging = false

                    when (cfg.id) {
                        "sprint" -> AutoSprintAccessibilityService.instance
                            ?.startSprintLoop(cfg.targetX, cfg.targetY)
                        "jump", "crouch" -> AutoSprintAccessibilityService.instance
                            ?.startHold(cfg.id, cfg.targetX, cfg.targetY)
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchStartX).toInt()
                    val dy = (event.rawY - touchStartY).toInt()
                    if (!isDragging && (Math.abs(dx) > 30 || Math.abs(dy) > 30)) {
                        isDragging = true
                        when (cfg.id) {
                            "sprint" -> AutoSprintAccessibilityService.instance?.stopSprintLoop()
                            "jump", "crouch" -> AutoSprintAccessibilityService.instance?.stopHold(cfg.id)
                        }
                    }
                    if (isDragging) {
                        val horiz = if (cfg.startGravity and Gravity.END == Gravity.END) -dx else dx
                        val vert = if (cfg.startGravity and Gravity.BOTTOM == Gravity.BOTTOM) -dy else dy
                        params.x = initialX + horiz
                        params.y = initialY + vert
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!isDragging) {
                        when (cfg.id) {
                            "sprint" -> AutoSprintAccessibilityService.instance?.stopSprintLoop()
                            "jump", "crouch" -> AutoSprintAccessibilityService.instance?.stopHold(cfg.id)
                        }
                    } else {
                        // Перетаскивание закончено — запоминаем новое место навсегда.
                        savePosition(cfg.id, params.x, params.y)
                    }
                    true
                }
                else -> false
            }
        }

        addedViews.add(btn)
        windowManager.addView(btn, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        AutoSprintAccessibilityService.instance?.stopSprintLoop()
        AutoSprintAccessibilityService.instance?.stopHold("jump")
        AutoSprintAccessibilityService.instance?.stopHold("crouch")
        addedViews.forEach { windowManager.removeView(it) }
        addedViews.clear()
    }
}

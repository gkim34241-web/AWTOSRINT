package com.example.autosprint

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Foreground-сервис, рисующий перетаскиваемые кнопки поверх игры:
 * SPRINT (тап-переключатель), JUMP, CROUCH, LEFT, RIGHT (обычные держим),
 * ATTACK (повторяющиеся тапы, пока держишь), и служебная ⚙ (калибровка).
 *
 * SPRINT теперь работает как ПЕРЕКЛЮЧАТЕЛЬ: короткий тап по кнопке = один
 * двойной тап в игру (в реальном MCPE двойной тап сам переключает спринт
 * туда-сюда). Персонаж перестаёт бежать только когда ты снова тапнешь
 * SPRINT (или сам остановишься/присядешь — это уже решает сама игра).
 * Больше никакого "держать кнопку" и никакого цикла, который мог мешать
 * другим кнопкам.
 *
 * JUMP / CROUCH / LEFT / RIGHT — обычное удержание (палец "стоит" на месте,
 * пока держишь кнопку), реализовано через AutoSprintAccessibilityService.
 *
 * ATTACK — пока держишь, каждые ~150мс улетает одиночный тап (эмуляция
 * быстрых повторяющихся ударов).
 *
 * Все held-действия (jump/crouch/left/right) и одноразовые тапы
 * (sprint-toggle/attack) теперь идут через ЕДИНЫЙ комбинированный диспатч
 * жестов в AutoSprintAccessibilityService — поэтому не сбрасывают друг
 * друга при одновременном использовании.
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: SharedPreferences
    private val addedViews = mutableListOf<android.view.View>()
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())

    private enum class Mode { TOGGLE_TAP, HOLD, REPEAT_TAP }

    private data class ButtonConfig(
        val id: String,
        val label: String,
        val bgColor: String,
        val defaultTargetX: Float,
        val defaultTargetY: Float,
        val startGravity: Int,
        val defaultX: Int,
        val defaultY: Int,
        val widthPx: Int,
        val heightPx: Int,
        val mode: Mode
    )

    private val fullW = 260; private val fullH = 160
    private val halfW = 130; private val halfH = 160 // "максимум половина от обычной кнопки"

    private val buttonConfigs = listOf(
        ButtonConfig(
            id = "sprint", label = "SPRINT", bgColor = "#8000FF00",
            defaultTargetX = 200f, defaultTargetY = 1600f,
            startGravity = Gravity.BOTTOM or Gravity.END,
            defaultX = 40, defaultY = 500, widthPx = fullW, heightPx = fullH,
            mode = Mode.TOGGLE_TAP
        ),
        ButtonConfig(
            id = "jump", label = "JUMP", bgColor = "#80FFAA00",
            defaultTargetX = 950f, defaultTargetY = 1550f,
            startGravity = Gravity.BOTTOM or Gravity.END,
            defaultX = 40, defaultY = 300, widthPx = fullW, heightPx = fullH,
            mode = Mode.HOLD
        ),
        ButtonConfig(
            id = "crouch", label = "CROUCH", bgColor = "#8000AAFF",
            defaultTargetX = 950f, defaultTargetY = 1750f,
            startGravity = Gravity.BOTTOM or Gravity.START,
            defaultX = 40, defaultY = 140, widthPx = fullW, heightPx = fullH,
            mode = Mode.HOLD
        ),
        ButtonConfig(
            id = "left", label = "◀", bgColor = "#80888888",
            defaultTargetX = 150f, defaultTargetY = 1550f,
            startGravity = Gravity.BOTTOM or Gravity.START,
            defaultX = 40, defaultY = 320, widthPx = halfW, heightPx = halfH,
            mode = Mode.HOLD
        ),
        ButtonConfig(
            id = "right", label = "▶", bgColor = "#80888888",
            defaultTargetX = 350f, defaultTargetY = 1550f,
            startGravity = Gravity.BOTTOM or Gravity.START,
            defaultX = 180, defaultY = 320, widthPx = halfW, heightPx = halfH,
            mode = Mode.HOLD
        ),
        ButtonConfig(
            id = "attack", label = "ATTACK", bgColor = "#80FF3333",
            defaultTargetX = 600f, defaultTargetY = 900f,
            startGravity = Gravity.BOTTOM or Gravity.END,
            defaultX = 40, defaultY = 700, widthPx = fullW, heightPx = fullH,
            mode = Mode.REPEAT_TAP
        )
    )

    private val calibrationQueue = ArrayDeque<String>()
    private var calibrationOverlay: FrameLayout? = null
    private val repeatRunnables = mutableMapOf<String, Runnable>()

    override fun onCreate() {
        super.onCreate()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("overlay_positions", Context.MODE_PRIVATE)
        buttonConfigs.forEach { addDraggableButton(it) }
        addCalibrateButton()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val channelId = "autosprint_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "AutoSprint Overlay", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NotificationManager::class.java)).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Оверлей активен")
            .setContentText("Sprint / Jump / Crouch / Left / Right / Attack готовы")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun loadSavedX(id: String, default: Int) = prefs.getInt("${id}_x", default)
    private fun loadSavedY(id: String, default: Int) = prefs.getInt("${id}_y", default)
    private fun savePosition(id: String, x: Int, y: Int) {
        prefs.edit().putInt("${id}_x", x).putInt("${id}_y", y).apply()
    }

    private fun loadTargetX(cfg: ButtonConfig) = prefs.getFloat("${cfg.id}_target_x", cfg.defaultTargetX)
    private fun loadTargetY(cfg: ButtonConfig) = prefs.getFloat("${cfg.id}_target_y", cfg.defaultTargetY)
    private fun saveTarget(id: String, x: Float, y: Float) {
        prefs.edit().putFloat("${id}_target_x", x).putFloat("${id}_target_y", y).apply()
    }

    private fun addDraggableButton(cfg: ButtonConfig) {
        val btn = Button(this).apply {
            text = cfg.label
            setBackgroundColor(Color.parseColor(cfg.bgColor))
            setTextColor(Color.WHITE)
            textSize = if (cfg.widthPx < fullW) 20f else 14f
        }

        val restoredX = loadSavedX(cfg.id, cfg.defaultX)
        val restoredY = loadSavedY(cfg.id, cfg.defaultY)

        val params = WindowManager.LayoutParams(
            cfg.widthPx, cfg.heightPx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = cfg.startGravity
            x = restoredX
            y = restoredY
        }

        var initialX = 0; var initialY = 0
        var touchStartX = 0f; var touchStartY = 0f
        var isDragging = false

        btn.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchStartX = event.rawX; touchStartY = event.rawY
                    isDragging = false

                    val tx = loadTargetX(cfg); val ty = loadTargetY(cfg)
                    when (cfg.mode) {
                        Mode.HOLD -> AutoSprintAccessibilityService.instance?.startHold(cfg.id, tx, ty)
                        Mode.REPEAT_TAP -> startRepeatTap(cfg.id, tx, ty)
                        Mode.TOGGLE_TAP -> { /* срабатывает на ACTION_UP, см. ниже */ }
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchStartX).toInt()
                    val dy = (event.rawY - touchStartY).toInt()
                    if (!isDragging && (Math.abs(dx) > 30 || Math.abs(dy) > 30)) {
                        isDragging = true
                        when (cfg.mode) {
                            Mode.HOLD -> AutoSprintAccessibilityService.instance?.stopHold(cfg.id)
                            Mode.REPEAT_TAP -> stopRepeatTap(cfg.id)
                            Mode.TOGGLE_TAP -> {}
                        }
                    }
                    if (isDragging) {
                        val horiz = if (cfg.startGravity and Gravity.END == Gravity.END) -dx else dx
                        val vert = if (cfg.startGravity and Gravity.BOTTOM == Gravity.BOTTOM) -dy else dy
                        params.x = initialX + horiz
                        params.y = initialY + vert
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!isDragging) {
                        val tx = loadTargetX(cfg); val ty = loadTargetY(cfg)
                        when (cfg.mode) {
                            Mode.HOLD -> AutoSprintAccessibilityService.instance?.stopHold(cfg.id)
                            Mode.REPEAT_TAP -> stopRepeatTap(cfg.id)
                            Mode.TOGGLE_TAP -> AutoSprintAccessibilityService.instance?.fireDoubleTap(tx, ty)
                        }
                    } else {
                        savePosition(cfg.id, params.x, params.y)
                    }
                    true
                }
                else -> false
            }
        }

        addedViews.add(btn)
        windowManager.addView(btn, params)
    }

    private fun startRepeatTap(key: String, x: Float, y: Float) {
        stopRepeatTap(key)
        val r = object : Runnable {
            override fun run() {
                AutoSprintAccessibilityService.instance?.fireSingleTap(x, y)
                handler.postDelayed(this, 150L)
            }
        }
        repeatRunnables[key] = r
        handler.post(r)
    }

    private fun stopRepeatTap(key: String) {
        repeatRunnables.remove(key)?.let { handler.removeCallbacks(it) }
    }

    private fun addCalibrateButton() {
        val btn = Button(this).apply {
            text = "⚙"
            setBackgroundColor(Color.parseColor("#80555555"))
            setTextColor(Color.WHITE)
            textSize = 16f
        }
        val params = WindowManager.LayoutParams(
            110, 110,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = loadSavedX("gear", 20)
            y = loadSavedY("gear", 100)
        }

        var initialX = 0; var initialY = 0
        var touchStartX = 0f; var touchStartY = 0f
        var isDragging = false

        btn.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    touchStartX = event.rawX; touchStartY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchStartX).toInt()
                    val dy = (event.rawY - touchStartY).toInt()
                    if (!isDragging && (Math.abs(dx) > 30 || Math.abs(dy) > 30)) isDragging = true
                    if (isDragging) {
                        params.x = initialX + dx; params.y = initialY + dy
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isDragging) savePosition("gear", params.x, params.y) else startCalibration()
                    true
                }
                else -> false
            }
        }

        addedViews.add(btn)
        windowManager.addView(btn, params)
    }

    private fun startCalibration() {
        calibrationQueue.clear()
        calibrationQueue.addAll(listOf("sprint", "jump", "crouch", "left", "right", "attack"))
        Toast.makeText(this, "Калибровка: 6 шагов. Тапай по настоящим кнопкам в игре.", Toast.LENGTH_LONG).show()
        askNextCalibrationTap()
    }

    private fun askNextCalibrationTap() {
        val nextId = calibrationQueue.removeFirstOrNull()
        if (nextId == null) {
            Toast.makeText(this, "Калибровка завершена ✔", Toast.LENGTH_LONG).show()
            return
        }
        showCalibrationCaptureLayer(nextId)
    }

    private fun showCalibrationCaptureLayer(id: String) {
        val label = buttonConfigs.find { it.id == id }?.label ?: id

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#22000000"))
        }
        val banner = TextView(this).apply {
            text = "Тапни, где в игре находится: $label"
            setBackgroundColor(Color.parseColor("#CC000000"))
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(24, 24, 24, 24)
        }
        root.addView(
            banner,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP
            )
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            0,
            PixelFormat.TRANSLUCENT
        )

        root.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                saveTarget(id, event.rawX, event.rawY)
                windowManager.removeView(root)
                calibrationOverlay = null
                Toast.makeText(this, "$label сохранён: (${event.rawX.toInt()}, ${event.rawY.toInt()})", Toast.LENGTH_SHORT).show()
                askNextCalibrationTap()
            }
            true
        }

        calibrationOverlay = root
        windowManager.addView(root, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        repeatRunnables.keys.toList().forEach { stopRepeatTap(it) }
        listOf("jump", "crouch", "left", "right").forEach {
            AutoSprintAccessibilityService.instance?.stopHold(it)
        }
        calibrationOverlay?.let { windowManager.removeView(it) }
        addedViews.forEach { windowManager.removeView(it) }
        addedViews.clear()
    }
}

package com.example.autosprint

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Единственная задача этого сервиса — отправлять системе синтетические
 * жесты через dispatchGesture(). Он НЕ читает содержимое экрана игры
 * (canRetrieveWindowContent="false" в конфиге) и не имеет доступа к
 * тому, что происходит внутри MCPE — только "нажимает"/"держит" в
 * заданных координатах, как это делал бы палец пользователя.
 *
 * Два разных механизма жестов:
 * - SPRINT: повторяющийся двойной тап, пока кнопка зажата (как раньше).
 * - JUMP / CROUCH: настоящее УДЕРЖАНИЕ пальца через continueStroke —
 *   один непрерывный жест, который мы продлеваем маленькими кусочками,
 *   пока пользователь держит кнопку, и обрываем, когда отпускает.
 *   Это даёт игре ровно то же самое, что и настоящий палец на экране.
 */
class AutoSprintAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AutoSprintAccessibilityService? = null
        private const val HOLD_SEGMENT_MS = 400L // на сколько мс продлеваем hold за раз
    }

    private val handler = Handler(Looper.getMainLooper())

    // --- SPRINT (двойной тап в цикле) ---
    private var sprintLoopRunnable: Runnable? = null
    private val doubleTapGapMs = 60L
    private val sprintRefreshMs = 900L

    // --- HOLD-кнопки (Jump/Crouch): отдельное состояние на каждый ключ кнопки ---
    private data class HoldState(
        var lastStroke: GestureDescription.StrokeDescription?,
        var active: Boolean,
        val x: Float,
        val y: Float
    )
    private val holds = mutableMapOf<String, HoldState>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        stopSprintLoop()
        holds.keys.toList().forEach { stopHold(it) }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ================= SPRINT =================

    fun startSprintLoop(x: Float, y: Float) {
        stopSprintLoop()
        val runnable = object : Runnable {
            override fun run() {
                dispatchDoubleTap(x, y)
                handler.postDelayed(this, sprintRefreshMs)
            }
        }
        sprintLoopRunnable = runnable
        handler.post(runnable)
    }

    fun stopSprintLoop() {
        sprintLoopRunnable?.let { handler.removeCallbacks(it) }
        sprintLoopRunnable = null
    }

    private fun dispatchDoubleTap(x: Float, y: Float) {
        dispatchSingleTap(x, y) {
            handler.postDelayed({ dispatchSingleTap(x, y) {} }, doubleTapGapMs)
        }
    }

    private fun dispatchSingleTap(x: Float, y: Float, onDone: () -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 40)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { onDone() }
            override fun onCancelled(g: GestureDescription?) { onDone() }
        }, null)
    }

    // ================= JUMP / CROUCH (настоящее удержание) =================

    /**
     * Начинает "держать палец" в точке (x, y) под ключом [key] (например "jump" или "crouch").
     * Вызывай на ACTION_DOWN кнопки-оверлея.
     */
    fun startHold(key: String, x: Float, y: Float) {
        stopHold(key) // на всякий случай сбрасываем предыдущее состояние
        val path = Path().apply { moveTo(x, y) }
        val firstSegment = GestureDescription.StrokeDescription(
            path, 0, HOLD_SEGMENT_MS, true // willContinue = true — жест не завершается
        )
        holds[key] = HoldState(firstSegment, true, x, y)
        dispatchGesture(
            GestureDescription.Builder().addStroke(firstSegment).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { extendHold(key) }
                override fun onCancelled(g: GestureDescription?) { /* остановлено извне */ }
            },
            null
        )
    }

    private fun extendHold(key: String) {
        val state = holds[key] ?: return
        if (!state.active) return
        val prevStroke = state.lastStroke ?: return

        // Продолжаем — палец "остаётся на месте" ещё HOLD_SEGMENT_MS.
        val path = Path().apply { moveTo(state.x, state.y) }
        val nextSegment = prevStroke.continueStroke(path, 0, HOLD_SEGMENT_MS, true)
        state.lastStroke = nextSegment
        dispatchGesture(
            GestureDescription.Builder().addStroke(nextSegment).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { extendHold(key) }
                override fun onCancelled(g: GestureDescription?) { /* остановлено извне */ }
            },
            null
        )
    }

    /** Отпускает "палец" — завершает удержание. Вызывай на ACTION_UP/CANCEL кнопки-оверлея. */
    fun stopHold(key: String) {
        val state = holds[key] ?: return
        state.active = false
        val prevStroke = state.lastStroke
        holds.remove(key)
        if (prevStroke != null) {
            // Финальный короткий сегмент с willContinue = false — корректно завершает жест.
            val path = Path().apply { moveTo(state.x, state.y) }
            val endSegment = prevStroke.continueStroke(path, 0, 20, false)
            dispatchGesture(GestureDescription.Builder().addStroke(endSegment).build(), null, null)
        }
    }
}

package com.example.autosprint

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * ВАЖНЫЙ технический момент, из-за которого раньше "JUMP сбрасывал SPRINT":
 * dispatchGesture() в Android документированно ОБРЫВАЕТ любой другой жест,
 * который уже выполняется, если его вызвать отдельным вызовом поверх уже
 * идущего. То есть если SPRINT и JUMP держатся каждый СВОИМ отдельным
 * dispatchGesture() — новый вызов (JUMP) гарантированно прерывает старый
 * (SPRINT), даже если они логически не должны друг другу мешать.
 *
 * Правильное решение — держать ВСЕ одновременно активные "пальцы"
 * (jump, crouch, left, right...) в ОДНОМ общем GestureDescription и
 * пересобирать/переотправлять его целиком одним вызовом каждый раз,
 * когда что-то меняется (нажали ещё одну кнопку, отпустили какую-то).
 * Тогда все held-кнопки существуют как один согласованный набор "пальцев"
 * и не обрывают друг друга.
 *
 * Отдельные быстрые действия (SPRINT-тап, ATTACK-тап) точно так же
 * подмешиваются в этот общий пакет одним вызовом, а не отдельным —
 * поэтому они тоже не сбрасывают активные hold-кнопки.
 */
class AutoSprintAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AutoSprintAccessibilityService? = null
        private const val HOLD_SEGMENT_MS = 400L
    }

    private val handler = Handler(Looper.getMainLooper())

    private data class HoldEntry(
        val x: Float,
        val y: Float,
        var lastStroke: GestureDescription.StrokeDescription?,
        var stopping: Boolean = false
    )

    // Все одновременно зажатые "пальцы": jump, crouch, left, right, attack(если удерживается)...
    private val activeHolds = mutableMapOf<String, HoldEntry>()

    // Одноразовые тапы (sprint-toggle, attack-single), которые нужно
    // подмешать в САМЫЙ БЛИЖАЙШИЙ общий dispatch, не создавая отдельный вызов.
    private val pendingOneShotTaps = mutableListOf<Pair<Float, Float>>()

    private var dispatchScheduled = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        activeHolds.clear()
        pendingOneShotTaps.clear()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ================= Публичное API =================

    /** Зажать "палец" в точке (x,y) под ключом [key] (jump/crouch/left/right/attack). */
    fun startHold(key: String, x: Float, y: Float) {
        activeHolds[key] = HoldEntry(x, y, lastStroke = null, stopping = false)
        scheduleImmediateDispatch()
    }

    /** Отпустить "палец" под ключом [key]. */
    fun stopHold(key: String) {
        val entry = activeHolds[key] ?: return
        if (entry.lastStroke == null) {
            // Ещё ни разу не диспатчился (отпустили мгновенно) — просто убираем.
            activeHolds.remove(key)
        } else {
            entry.stopping = true
            scheduleImmediateDispatch()
        }
    }

    /** Одноразовый двойной тап (используется для переключателя SPRINT). */
    fun fireDoubleTap(x: Float, y: Float) {
        pendingOneShotTaps.add(x to y)
        handler.postDelayed({ pendingOneShotTaps.add(x to y) }, 70L)
        scheduleImmediateDispatch()
    }

    /** Одноразовый одиночный тап (используется для ATTACK). */
    fun fireSingleTap(x: Float, y: Float) {
        pendingOneShotTaps.add(x to y)
        scheduleImmediateDispatch()
    }

    // ================= Внутренняя логика =================

    private fun scheduleImmediateDispatch() {
        if (dispatchScheduled) return
        dispatchScheduled = true
        handler.post {
            dispatchScheduled = false
            performCombinedDispatch()
        }
    }

    private fun performCombinedDispatch() {
        if (activeHolds.isEmpty() && pendingOneShotTaps.isEmpty()) return

        val builder = GestureDescription.Builder()
        val keysToRemoveAfter = mutableListOf<String>()

        // 1. Продолжаем/начинаем все активные hold-пальцы.
        for ((key, entry) in activeHolds) {
            val path = Path().apply { moveTo(entry.x, entry.y) }
            val stroke = if (entry.lastStroke == null) {
                GestureDescription.StrokeDescription(path, 0, HOLD_SEGMENT_MS, !entry.stopping)
            } else {
                entry.lastStroke!!.continueStroke(
                    path, 0,
                    if (entry.stopping) 20L else HOLD_SEGMENT_MS,
                    !entry.stopping
                )
            }
            entry.lastStroke = stroke
            builder.addStroke(stroke)
            if (entry.stopping) keysToRemoveAfter.add(key)
        }

        // 2. Подмешиваем одноразовые тапы (sprint-toggle / attack) отдельными "пальцами".
        val oneShotsThisRound = pendingOneShotTaps.toList()
        pendingOneShotTaps.clear()
        for ((x, y) in oneShotsThisRound) {
            val path = Path().apply { moveTo(x, y) }
            builder.addStroke(GestureDescription.StrokeDescription(path, 0, 40))
        }

        dispatchGesture(builder.build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                keysToRemoveAfter.forEach { activeHolds.remove(it) }
                // Если есть ещё активные holds — продлеваем их следующим сегментом.
                if (activeHolds.isNotEmpty()) {
                    handler.postDelayed({ performCombinedDispatch() }, 0L)
                }
            }
            override fun onCancelled(g: GestureDescription?) {
                keysToRemoveAfter.forEach { activeHolds.remove(it) }
            }
        }, null)
    }
}

package com.example.autosprint

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Все активные удержания и одноразовые тапы идут через ОДИН жест за раз.
 * Новый dispatch не стартует, пока не завершился предыдущий — иначе Android
 * отменяет старый жест, и continueStroke() падает с
 * IllegalStateException: Only strokes marked willContinue can be continued.
 */
class AutoSprintAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AutoSprintAccessibilityService? = null
        private const val HOLD_SEGMENT_MS = 220L
        private const val TAP_MS = 35L
    }

    private val handler = Handler(Looper.getMainLooper())

    private data class HoldEntry(
        val x: Float,
        val y: Float,
        var lastStroke: GestureDescription.StrokeDescription? = null,
        var canContinue: Boolean = false,
        var stopping: Boolean = false
    )

    private val activeHolds = mutableMapOf<String, HoldEntry>()
    private val pendingOneShotTaps = mutableListOf<Pair<Float, Float>>()

    private var dispatchInFlight = false
    private var dispatchNeeded = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        activeHolds.clear()
        pendingOneShotTaps.clear()
        dispatchInFlight = false
        dispatchNeeded = false
        handler.removeCallbacksAndMessages(null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun startHold(key: String, x: Float, y: Float) {
        activeHolds[key] = HoldEntry(x, y)
        requestDispatch()
    }

    fun stopHold(key: String) {
        val entry = activeHolds[key] ?: return
        if (entry.lastStroke == null || !entry.canContinue) {
            activeHolds.remove(key)
            return
        }
        entry.stopping = true
        requestDispatch()
    }

    fun fireDoubleTap(x: Float, y: Float) {
        pendingOneShotTaps.add(x to y)
        requestDispatch()
        handler.postDelayed({
            pendingOneShotTaps.add(x to y)
            requestDispatch()
        }, 70L)
    }

    fun fireSingleTap(x: Float, y: Float) {
        pendingOneShotTaps.add(x to y)
        requestDispatch()
    }

    private fun requestDispatch() {
        dispatchNeeded = true
        if (dispatchInFlight) return
        handler.post { performCombinedDispatch() }
    }

    private fun performCombinedDispatch() {
        if (dispatchInFlight) return
        dispatchNeeded = false
        if (activeHolds.isEmpty() && pendingOneShotTaps.isEmpty()) return

        try {
            val builder = GestureDescription.Builder()
            val keysToRemoveAfter = mutableListOf<String>()

            for ((key, entry) in activeHolds.toList()) {
                val path = Path().apply { moveTo(entry.x, entry.y) }
                val duration = if (entry.stopping) 20L else HOLD_SEGMENT_MS
                val willContinue = !entry.stopping
                val stroke = if (entry.canContinue && entry.lastStroke != null) {
                    try {
                        entry.lastStroke!!.continueStroke(path, 0, duration, willContinue)
                    } catch (_: IllegalStateException) {
                        GestureDescription.StrokeDescription(path, 0, duration, willContinue)
                    }
                } else {
                    GestureDescription.StrokeDescription(path, 0, duration, willContinue)
                }
                entry.lastStroke = stroke
                entry.canContinue = willContinue
                builder.addStroke(stroke)
                if (entry.stopping) keysToRemoveAfter.add(key)
            }

            val oneShots = pendingOneShotTaps.toList()
            pendingOneShotTaps.clear()
            for ((x, y) in oneShots) {
                val path = Path().apply { moveTo(x, y) }
                builder.addStroke(GestureDescription.StrokeDescription(path, 0, TAP_MS))
            }

            dispatchInFlight = true
            val started = dispatchGesture(
                builder.build(),
                object : GestureResultCallback() {
                    override fun onCompleted(g: GestureDescription?) {
                        finishDispatch(keysToRemoveAfter, cancelled = false)
                    }
                    override fun onCancelled(g: GestureDescription?) {
                        finishDispatch(keysToRemoveAfter, cancelled = true)
                    }
                },
                null
            )
            if (!started) {
                dispatchInFlight = false
                activeHolds.values.forEach {
                    it.canContinue = false
                    it.lastStroke = null
                }
            }
        } catch (e: Exception) {
            dispatchInFlight = false
            activeHolds.values.forEach {
                it.canContinue = false
                it.lastStroke = null
            }
        }
    }

    private fun finishDispatch(keysToRemove: List<String>, cancelled: Boolean) {
        dispatchInFlight = false
        keysToRemove.forEach { activeHolds.remove(it) }
        if (cancelled) {
            activeHolds.values.forEach {
                it.canContinue = false
                it.lastStroke = null
            }
        }
        if (activeHolds.isNotEmpty() || pendingOneShotTaps.isNotEmpty() || dispatchNeeded) {
            handler.post { performCombinedDispatch() }
        }
    }
}

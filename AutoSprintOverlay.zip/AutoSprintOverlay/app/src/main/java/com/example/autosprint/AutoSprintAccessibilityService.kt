package com.example.autosprint

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Единственная задача этого сервиса — отправлять системе синтетические
 * жесты (двойной тап) через dispatchGesture(). Он НЕ читает содержимое
 * экрана игры (canRetrieveWindowContent="false" в конфиге) и не имеет
 * доступа к тому, что происходит внутри MCPE — только "нажимает" в
 * заданных координатах, как это делал бы палец пользователя.
 */
class AutoSprintAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AutoSprintAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var loopRunnable: Runnable? = null

    // Пауза между "нажатиями двойного тапа" — эмулируем удержание спринта,
    // повторяя двойной тап раз в SPRINT_REFRESH_MS, пока кнопка зажата.
    private val doubleTapGapMs = 60L
    private val sprintRefreshMs = 900L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        stopSprintLoop()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Не используется — сервис не следит за событиями других приложений.
    }

    override fun onInterrupt() {}

    /** Запускает цикл повторяющегося двойного тапа, пока кнопка на оверлее зажата. */
    fun startSprintLoop(x: Float, y: Float) {
        stopSprintLoop()
        val runnable = object : Runnable {
            override fun run() {
                dispatchDoubleTap(x, y)
                handler.postDelayed(this, sprintRefreshMs)
            }
        }
        loopRunnable = runnable
        handler.post(runnable)
    }

    fun stopSprintLoop() {
        loopRunnable?.let { handler.removeCallbacks(it) }
        loopRunnable = null
    }

    private fun dispatchDoubleTap(x: Float, y: Float) {
        dispatchSingleTap(x, y) {
            handler.postDelayed({ dispatchSingleTap(x, y) {} }, doubleTapGapMs)
        }
    }

    private fun dispatchSingleTap(x: Float, y: Float, onDone: () -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 40)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onDone()
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                onDone()
            }
        }, null)
    }
}

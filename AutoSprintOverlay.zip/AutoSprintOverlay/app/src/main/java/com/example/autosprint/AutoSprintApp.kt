package com.example.autosprint

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Ловит любой необработанный краш всего приложения (Activity или
 * фонового сервиса) и записывает полный текст ошибки в файл
 * crash_log.txt внутри памяти приложения. MainActivity при следующем
 * открытии проверяет этот файл и показывает его содержимое на экране —
 * это позволяет присылать точный текст ошибки без компьютера и логов.
 */
class AutoSprintApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                File(filesDir, "crash_log.txt").writeText(sw.toString())
            } catch (_: Exception) {
                // если даже запись лога упала — молча пропускаем, лишь бы не зациклиться
            }
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }
}

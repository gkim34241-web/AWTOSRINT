package com.example.autosprint

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.Manifest
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)

        // Если в прошлый раз приложение упало — покажем текст ошибки
        // сразу при открытии, чтобы можно было прислать скриншот.
        showCrashLogIfAny()

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }

        // Шаг 1: разрешение "рисовать поверх других приложений"
        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                statusText.text = "Оверлей: разрешён ✔"
            }
        }

        // Шаг 2: включение Accessibility Service вручную в системных настройках
        findViewById<Button>(R.id.btnGrantAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // Шаг 3: запуск foreground-сервиса с оверлеем
        findViewById<Button>(R.id.btnStartOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                statusText.text = "Сначала выдай разрешение на оверлей!"
                return@setOnClickListener
            }
            val serviceIntent = Intent(this, OverlayService::class.java)
            startForegroundService(serviceIntent)
            statusText.text = "Оверлей запущен. Сверни приложение и открой MCPE."
        }

        // Полностью выключить оверлей и убрать все кнопки с экрана.
        findViewById<Button>(R.id.btnStopOverlay).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            statusText.text = "Оверлей остановлен. Кнопки убраны с экрана."
        }
    }

    private fun showCrashLogIfAny() {
        val logFile = File(filesDir, "crash_log.txt")
        if (logFile.exists()) {
            val text = logFile.readText()
            AlertDialog.Builder(this)
                .setTitle("Приложение падало — вот текст ошибки")
                .setMessage(text)
                .setPositiveButton("Скопировать понятно, закрыть") { _, _ ->
                    logFile.delete()
                }
                .setCancelable(false)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        val overlayOk = Settings.canDrawOverlays(this)
        statusText.text = if (overlayOk) "Оверлей: разрешён ✔" else "Оверлей: НЕ разрешён"
    }
}

package com.example.autosprint

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)

        // Шаг 1: разрешение "рисовать поверх других приложений"
        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                statusText.text = "Оверлей: разрешён ✔"
            }
        }

        // Шаг 2: включение Accessibility Service вручную в системных настройках
        // (Android не позволяет включить его программно — только через UI пользователя,
        //  это специально сделано против скрытной активации таких сервисов)
        findViewById<Button>(R.id.btnGrantAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // Шаг 3: запуск foreground-сервиса с оверлеем
        findViewById<Button>(R.id.btnStartOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                statusText.text = "Сначала выдай разрешение на оверлей!"
                return@setOnClickListener
            }
            val serviceIntent = Intent(this, OverlayService::class.java)
            startForegroundService(serviceIntent)
            statusText.text = "Оверлей запущен. Сверни приложение и открой MCPE."
        }
    }

    override fun onResume() {
        super.onResume()
        val overlayOk = Settings.canDrawOverlays(this)
        statusText.text = if (overlayOk) "Оверлей: разрешён ✔" else "Оверлей: НЕ разрешён"
    }
}

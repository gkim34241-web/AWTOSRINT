package com.example.autosprint

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Единый мультитач-диспетчер для всех игровых действий.
 *
 * Важно: Android отменяет предыдущий dispatchGesture(), если поверх него
 * отправить новый. Поэтому мы никогда не запускаем второй dispatch, пока
 * текущий пакет ещё выполняется. Все активные удержания и ожидающие быстрые
 * тапы собираются в ОДИН GestureDescription и отправляются вместе.
 *
 * Таким образом можно одновременно держать JUMP + CROUCH + LEFT + RIGHT,
 * а SPRINT/ATTACK будут добавляться в ближайший пакет, не сбрасывая
 * остальные удержания.
 */
class AutoSprintAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AutoSprintAccessibilityService? = null

        // Чем меньше сегмент, тем меньше задержка перед новым действием,
        // пока уже выполняется удержание. 32 мс ~= 2 кадра при 60 FPS.
        private const val HOLD_SEGMENT_MS = 32L
        private const val RELEASE_SEGMENT_MS = 12L
        private const val TAP_DURATION_MS = 8L
        private const val DOUBLE_TAP_GAP_MS = 35L
    }

    private val handler = Handler(Looper.getMainLooper())

    private data class HoldEntry(
        val x: Float,
        val y: Float,
        var lastStroke: GestureDescription.StrokeDescription? = null,
        var stopping: Boolean = false
    )

    private data class OneShotTap(
        val x: Float,
        val y: Float,
        val startTime: Long = 0L,
        val duration: Long = TAP_DURATION_MS
    )

    /** Все одновременно удерживаемые виртуальные пальцы. */
    private val activeHolds = LinkedHashMap<String, HoldEntry>()

    /** Быстрые действия, которые попадут в следующий общий пакет. */
    private val pendingOneShotTaps = ArrayDeque<OneShotTap>()

    private var dispatchInFlight = false
    private var dispatchDirty = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        activeHolds.clear()
        pendingOneShotTaps.clear()
        dispatchDirty = false
        dispatchInFlight = false
        handler.removeCallbacksAndMessages(null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    // ================= Public API =================

    fun startHold(key: String, x: Float, y: Float) {
        val old = activeHolds[key]
        if (old != null && !old.stopping) return

        activeHolds[key] = HoldEntry(x, y)
        requestDispatch()
    }

    fun stopHold(key: String) {
        val entry = activeHolds[key] ?: return
        if (entry.lastStroke == null) {
            activeHolds.remove(key)
            return
        }
        entry.stopping = true
        requestDispatch()
    }

    /** Двойной тап для переключения спринта. */
    fun fireDoubleTap(x: Float, y: Float) {
        pendingOneShotTaps.addLast(OneShotTap(x, y, 0L))
        pendingOneShotTaps.addLast(OneShotTap(x, y, DOUBLE_TAP_GAP_MS))
        requestDispatch()
    }

    /** Один быстрый тап для ATTACK. */
    fun fireSingleTap(x: Float, y: Float) {
        pendingOneShotTaps.addLast(OneShotTap(x, y))
        requestDispatch()
    }

    // ================= Dispatcher =================

    private fun requestDispatch() {
        dispatchDirty = true
        if (!dispatchInFlight) {
            performCombinedDispatch()
        }
    }

    private fun performCombinedDispatch() {
        if (dispatchInFlight) return

        if (activeHolds.isEmpty() && pendingOneShotTaps.isEmpty()) {
            dispatchDirty = false
            return
        }

        dispatchDirty = false
        dispatchInFlight = true

        val builder = GestureDescription.Builder()
        val stoppingKeys = ArrayList<String>()

        // Каждый activeHold = отдельный виртуальный палец.
        // Все такие пальцы попадают в один GestureDescription.
        for ((key, entry) in activeHolds) {
            val path = Path().apply {
                moveTo(entry.x, entry.y)
            }

            val stroke = entry.lastStroke?.let { previous ->
                previous.continueStroke(
                    path,
                    0L,
                    if (entry.stopping) RELEASE_SEGMENT_MS else HOLD_SEGMENT_MS,
                    willContinue = !entry.stopping
                )
            } ?: GestureDescription.StrokeDescription(
                path,
                0L,
                if (entry.stopping) RELEASE_SEGMENT_MS else HOLD_SEGMENT_MS,
                willContinue = !entry.stopping
            )

            entry.lastStroke = stroke
            builder.addStroke(stroke)

            if (entry.stopping) {
                stoppingKeys.add(key)
            }
        }

        // Быстрые тапы идут в тот же самый GestureDescription,
        // поэтому они могут выполняться одновременно с удержаниями.
        while (pendingOneShotTaps.isNotEmpty()) {
            val tap = pendingOneShotTaps.removeFirst()
            val path = Path().apply {
                moveTo(tap.x, tap.y)
            }
            builder.addStroke(
                GestureDescription.StrokeDescription(
                    path,
                    tap.startTime,
                    tap.duration
                )
            )
        }

        val gesture = try {
            builder.build()
        } catch (_: Throwable) {
            dispatchInFlight = false
            // Не теряем команды: повторим отправку чуть позже.
            dispatchDirty = true
            handler.postDelayed({ performCombinedDispatch() }, 8L)
            return
        }

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                dispatchInFlight = false
                stoppingKeys.forEach { activeHolds.remove(it) }
                continueIfNeeded()
            }

            override fun onCancelled(g: GestureDescription?) {
                dispatchInFlight = false
                // При отмене не выбрасываем активные удержания.
                // Следующий общий пакет восстановит их.
                continueIfNeeded()
            }
        }, null)
    }

    private fun continueIfNeeded() {
        if (dispatchDirty || activeHolds.isNotEmpty() || pendingOneShotTaps.isNotEmpty()) {
            performCombinedDispatch()
        }
    }

}

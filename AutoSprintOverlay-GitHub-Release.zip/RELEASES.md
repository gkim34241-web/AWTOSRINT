# Автоматические релизы

После каждого `push` в ветку `main` или `master` GitHub Actions:

1. Собирает APK.
2. Загружает APK в Artifacts.
3. Создаёт новый GitHub Release с тегом вида `v1`, `v2`, `v3` и т.д.
4. Прикрепляет `AutoSprintOverlay-debug.apk` прямо к Release.

Также сборку можно запустить вручную через **Actions → Build & Release APK → Run workflow**.
